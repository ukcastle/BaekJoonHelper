def solution():

	inputString = input()

	print(inputString)