def solution():

	n = int(input())

	print()


# import sys
# input = sys.stdin.readline
# solution()

# --- 제출할 때 주석 풀기 ---